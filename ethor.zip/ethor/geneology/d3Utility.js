// Modification of the base, D3 collapsible tree code found here: https://bl.ocks.org/mbostock/4339083
// Copyright (C) 2017  Floyd Hightower

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

var D3UTILITY = D3UTILITY || {};

var tree, root, svg, i, diagonal, duration,contract;

// Toggle children on click.
function click(d) {
    DYNAMICTREE.updateJson(d,contract);
    // if (d.children) {
    //     d._children = d.children;
    //     d.children = null;
    // } else {
    //     d.children = d._children;
    //     d._children = null;
    // }
    // update(d);
}

D3UTILITY.drawTree = function( data,contractObj ) {

    contract = contractObj
    var margin = {top: 20, right: 120, bottom: 20, left: 120},
    width = 860 - margin.right - margin.left,
    height = 800 - margin.top - margin.bottom;

    i = 0;
    duration = 750;

    tree = d3.layout.tree()
    .size([height, width]);

    diagonal = d3.svg.diagonal()
    .projection(function(d) { return [d.y, d.x]; });

    svg = d3.select("#network_svg").append("svg")
    .attr("width", width + margin.right + margin.left)
    .attr("height", height + margin.top + margin.bottom)
    .call(d3.behavior.zoom()
              .scaleExtent([0.5, 5])
              .on("zoom", zoom))
    .append("svg:g")
    .attr("class","drawarea")
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

   

    // the path below needs to be the path to the json file from index.html (from which this js file is called)
    // d3.json(PIVOTER.treeJson, function(error, flare) {
        // if (error) throw error;

    // this takes the json from the PIVOTER rather than the json file
    root = data;
    root.x0 = height / 2;
    root.y0 = 0;

    function collapse(d) {
        if (d.children) {
          d._children = d.children;
          d._children.forEach(collapse);
          d.children = null;
        }
    }

  collapse(root);
  // root.children.forEach(collapse);
  D3UTILITY.update(root);
    // });

    d3.select(self.frameElement).style("height", "800px");

    function zoom() {
      var scale = d3.event.scale,
          translation = d3.event.translate,
          tbound = -height * scale,
          bbound = height * scale,
          lbound = (-width + margin.right) * scale,
          rbound = (width - margin.left) * scale;
      // limit translation to thresholds
      translation = [
          Math.max(Math.min(translation[0], rbound), lbound),
          Math.max(Math.min(translation[1], bbound), tbound)
      ];
      d3.select(".drawarea")
          .attr("transform", "translate(" + translation + ")" +
                " scale(" + scale + ")");
    }
    
};


D3UTILITY.update =  function(source) {
    // Compute the new tree layout.
    var nodes = tree.nodes(root).reverse(),
      links = tree.links(nodes);

    // Normalize for fixed-depth.
    nodes.forEach(function(d) { d.y = d.depth * 100; });

    // Update the nodes…
    var node = svg.selectAll("g.node")
      .data(nodes, function(d) { return d.id || (d.id = ++i); });

    // Enter any new nodes at the parent's previous position.
    var nodeEnter = node.enter().append("g")
      .attr("class", "node")
      .attr("transform", function(d) { return "translate(" + source.y0 + "," + source.x0 + ")"; })
      .on("click", click);

    nodeEnter.append("circle")
      .attr("r", 1e-6)
      .style("fill", function(d) { return d._children ? "lightsteelblue" : "#fff"; });

    nodeEnter.append("text")
      .attr("x", function(d) { return d.children || d._children ? -10 : 10; })
      .attr("dy", ".35em")
      .attr("text-anchor", function(d) { return d.children || d._children ? "end" : "start"; })
      .text(function(d) { return d.name; })
      .style("fill-opacity", 1e-6);

    // Transition nodes to their new position.
    var nodeUpdate = node.transition()
      .duration(duration)
      .attr("transform", function(d) { return "translate(" + d.y + "," + d.x + ")"; });

    nodeUpdate.select("circle")
      .attr("r", 4.5)
      .style("fill", function(d) { return d._children ? "lightsteelblue" : "#fff"; });

    nodeUpdate.select("text")
      .style("fill-opacity", 1);

    // Transition exiting nodes to the parent's new position.
    var nodeExit = node.exit().transition()
      .duration(duration)
      .attr("transform", function(d) { return "translate(" + source.y + "," + source.x + ")"; })
      .remove();

    nodeExit.select("circle")
      .attr("r", 1e-6);

    nodeExit.select("text")
      .style("fill-opacity", 1e-6);

    // Update the links…
    var link = svg.selectAll("path.link")
      .data(links, function(d) { return d.target.id; });

    // Enter any new links at the parent's previous position.
    link.enter().insert("path", "g")
      .attr("class", "link")
      .attr("d", function(d) {
        var o = {x: source.x0, y: source.y0};
        return diagonal({source: o, target: o});
      });

    // Transition links to their new position.
    link.transition()
      .duration(duration)
      .attr("d", diagonal);

    // Transition exiting nodes to the parent's new position.
    link.exit().transition()
      .duration(duration)
      .attr("d", function(d) {
        var o = {x: source.x, y: source.y};
        return diagonal({source: o, target: o});
      })
      .remove();

    // Stash the old positions for transition.
    nodes.forEach(function(d) {
    d.x0 = d.x;
    d.y0 = d.y;
    });

   
  
};

